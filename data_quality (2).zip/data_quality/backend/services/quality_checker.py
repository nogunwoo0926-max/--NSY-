"""
5대 데이터 품질 지표 진단 모듈
플로우차트 STEP 2~3 구현:
  1) 완전성 (Completeness)  : Null/결측 검사
  2) 유효성 (Validity)       : 타입/범위 검증
  3) 일관성 (Consistency)    : 형식/단위 통일
  4) 이상치 (Accuracy)       : IQR + Z-Score + Isolation Forest 다수결
  5) 중복성 (Uniqueness)     : 중복/키 검사

모든 함수는 pandas DataFrame → dict 형태의 순수 함수 (DB/HTTP 의존 없음).
"""
import re
import numpy as np
import pandas as pd
from typing import Dict, Any, List
from sklearn.ensemble import IsolationForest


# ====================================================================
# 기본 정보
# ====================================================================
def get_basic_info(df: pd.DataFrame) -> Dict[str, Any]:
    """데이터프레임 기본 메타 정보"""
    numeric_cols = df.select_dtypes(include="number").columns.tolist()
    categorical_cols = df.select_dtypes(include=["object", "category"]).columns.tolist()

    return {
        "rows": len(df),
        "cols": len(df.columns),
        "numeric_cols": len(numeric_cols),
        "categorical_cols": len(categorical_cols),
        "numeric_col_names": numeric_cols,
        "categorical_col_names": categorical_cols,
    }


# ====================================================================
# 1) 완전성 (Completeness) - Null/결측 검사
# ====================================================================
def check_completeness(df: pd.DataFrame) -> Dict[str, Any]:
    """
    완전성: 결측치가 적을수록 좋음
    점수 = (1 - 결측셀/전체셀) × 100
    """
    total_cells = df.size if df.size > 0 else 1
    missing_per_col = df.isnull().sum()
    total_missing = int(missing_per_col.sum())
    overall_ratio = total_missing / total_cells

    per_column_ratio = (missing_per_col / len(df)).to_dict() if len(df) > 0 else {}

    return {
        "score": round((1 - overall_ratio) * 100, 2),
        "overall_ratio": float(overall_ratio),
        "total_missing": total_missing,
        "per_column": per_column_ratio,
        "per_column_count": {k: int(v) for k, v in missing_per_col.to_dict().items()},
    }


# ====================================================================
# 2) 유효성 (Validity) - 타입/범위 검증
# ====================================================================
def check_validity(df: pd.DataFrame) -> Dict[str, Any]:
    """
    유효성: 데이터가 올바른 타입과 범위 내에 있는가
    - object 컬럼이지만 숫자/날짜로 변환 가능한 셀 → 타입 불일치 카운트
    - 수치형 컬럼에서 inf, -inf → 무효 값
    점수 = (1 - 무효셀/전체셀) × 100
    """
    invalid_count = 0
    invalid_per_col: Dict[str, int] = {}
    issues: List[Dict[str, str]] = []

    THRESHOLD = 0.7  # 70% 이상이 숫자/날짜면 해당 타입으로 간주

    for col in df.columns:
        col_invalid = 0

        # object 또는 string dtype 모두 처리
        is_string = (
            df[col].dtype == "object"
            or pd.api.types.is_string_dtype(df[col])
        ) and not pd.api.types.is_numeric_dtype(df[col])

        if is_string:
            series = df[col].dropna().astype(str).str.strip()
            if len(series) == 0:
                invalid_per_col[col] = 0
                continue

            # 숫자형으로 변환 가능한 비율
            numeric_converted = pd.to_numeric(series, errors="coerce")
            numeric_ratio = numeric_converted.notna().sum() / len(series)

            # 날짜형 변환 가능한 비율 (소규모 샘플로 빠르게 체크)
            sample = series.head(min(100, len(series)))
            try:
                date_converted_sample = pd.to_datetime(sample, errors="coerce", format="mixed")
            except (ValueError, TypeError):
                date_converted_sample = pd.to_datetime(sample, errors="coerce")
            date_ratio = date_converted_sample.notna().sum() / len(sample)

            # 숫자 vs 날짜 중 비율 높은 쪽으로 판정
            if numeric_ratio >= THRESHOLD and numeric_ratio >= date_ratio:
                col_invalid = int(numeric_converted.isna().sum())
                if col_invalid > 0:
                    issues.append({
                        "column": col,
                        "current_dtype": "object",
                        "suggested_dtype": "numeric",
                        "convertible_ratio": f"{numeric_ratio*100:.1f}%",
                        "issue": f"숫자형이어야 할 컬럼에 비숫자 값 {col_invalid}개 존재",
                    })
            elif date_ratio >= THRESHOLD:
                try:
                    full_date = pd.to_datetime(series, errors="coerce", format="mixed")
                except (ValueError, TypeError):
                    full_date = pd.to_datetime(series, errors="coerce")
                col_invalid = int(full_date.isna().sum())
                if col_invalid > 0:
                    issues.append({
                        "column": col,
                        "current_dtype": "object",
                        "suggested_dtype": "datetime",
                        "convertible_ratio": f"{date_ratio*100:.1f}%",
                        "issue": f"날짜형이어야 할 컬럼에 비날짜 값 {col_invalid}개 존재",
                    })

        elif pd.api.types.is_numeric_dtype(df[col]):
            # 수치형: inf 검출
            inf_count = int(np.isinf(df[col].fillna(0)).sum())
            if inf_count > 0:
                col_invalid = inf_count
                issues.append({
                    "column": col,
                    "current_dtype": str(df[col].dtype),
                    "suggested_dtype": "-",
                    "convertible_ratio": "-",
                    "issue": f"무한대(inf) 값 {inf_count}개 포함",
                })

        invalid_per_col[col] = col_invalid
        invalid_count += col_invalid

    total_cells = df.size if df.size > 0 else 1
    invalid_ratio = invalid_count / total_cells

    return {
        "score": round((1 - invalid_ratio) * 100, 2),
        "invalid_count": invalid_count,
        "invalid_ratio": float(invalid_ratio),
        "per_column": invalid_per_col,
        "issues": issues,
    }


# ====================================================================
# 3) 일관성 (Consistency) - 형식/단위 통일
# ====================================================================
def check_consistency(df: pd.DataFrame) -> Dict[str, Any]:
    """
    일관성: 문자열 컬럼에서 형식이 통일되어 있는가
    검사 항목:
      - 앞뒤 공백 있는 셀
      - 동일 값이지만 대소문자 다른 셀 (예: 'KOREA' vs 'korea')
      - 혼합된 표기 (예: '2024-01-01' vs '2024/01/01')
    점수 = (1 - 비일관셀/전체셀) × 100
    """
    inconsistent_count = 0
    per_column: Dict[str, int] = {}

    for col in df.columns:
        # object 또는 string dtype 모두 처리
        is_string = (
            df[col].dtype == "object"
            or pd.api.types.is_string_dtype(df[col])
        ) and not pd.api.types.is_numeric_dtype(df[col])

        if not is_string:
            per_column[col] = 0
            continue

        series = df[col].dropna().astype(str)
        if len(series) == 0:
            per_column[col] = 0
            continue

        col_inconsistent = 0

        # ① 앞뒤 공백 검사 - 셀 단위
        whitespace_mask = series != series.str.strip()
        col_inconsistent += int(whitespace_mask.sum())

        # ② 대소문자 변형 검사 - 정규화 후 동일한 값을 가진 셀들 중
        #    가장 많이 등장하는 표기와 다른 셀의 개수
        normalized = series.str.strip().str.lower()
        # 정규화된 값으로 그룹핑
        for norm_val, group in series.groupby(normalized):
            if len(group) <= 1:
                continue
            stripped = group.str.strip()
            if stripped.nunique() > 1:
                # 같은 의미(소문자 기준)인데 표기가 여러 개 → 가장 많은 표기 외 나머지가 비일관
                top_form_count = stripped.value_counts().iloc[0]
                col_inconsistent += len(group) - int(top_form_count)

        # ③ 날짜/숫자 형식 혼용 검사 (구분자 통일성)
        sample = series.head(min(500, len(series)))
        date_dash = int(sample.str.match(r"^\d{4}-\d{2}-\d{2}").sum())
        date_slash = int(sample.str.match(r"^\d{4}/\d{2}/\d{2}").sum())
        if date_dash > 0 and date_slash > 0:
            # 두 형식이 섞여 있으면 적은 쪽을 비일관으로 카운트
            col_inconsistent += min(date_dash, date_slash)

        per_column[col] = col_inconsistent
        inconsistent_count += col_inconsistent

    total_cells = df.size if df.size > 0 else 1
    inconsistent_ratio = inconsistent_count / total_cells

    return {
        "score": round((1 - inconsistent_ratio) * 100, 2),
        "inconsistent_count": inconsistent_count,
        "inconsistent_ratio": float(inconsistent_ratio),
        "per_column": per_column,
    }


# ====================================================================
# 4) 이상치 (Accuracy) - IQR + Z-Score + Isolation Forest 다수결
# ====================================================================
def _detect_outliers_iqr(series: pd.Series) -> np.ndarray:
    """IQR 기반 이상치 탐지 → boolean mask 반환"""
    if len(series) < 4:
        return np.zeros(len(series), dtype=bool)
    q1 = series.quantile(0.25)
    q3 = series.quantile(0.75)
    iqr = q3 - q1
    if iqr == 0:
        return np.zeros(len(series), dtype=bool)
    lower = q1 - 1.5 * iqr
    upper = q3 + 1.5 * iqr
    return ((series < lower) | (series > upper)).values


def _detect_outliers_zscore(series: pd.Series, threshold: float = 3.0) -> np.ndarray:
    """Z-Score 기반 이상치 탐지 → |Z| >= 3"""
    if len(series) < 2:
        return np.zeros(len(series), dtype=bool)
    std = series.std()
    if std == 0 or pd.isna(std):
        return np.zeros(len(series), dtype=bool)
    z = np.abs((series - series.mean()) / std)
    return (z >= threshold).values


def _detect_outliers_isoforest(series: pd.Series, contamination: float = 0.05) -> np.ndarray:
    """
    Isolation Forest 기반 이상치 탐지
    대용량 데이터 대응: max_samples로 학습에 쓰는 표본 수를 제한해 속도 확보
    (전체 데이터에 대한 예측은 그대로 수행)
    """
    n = len(series)
    if n < 10:
        return np.zeros(n, dtype=bool)
    try:
        # 학습 표본 수 제한: 데이터가 커도 최대 25,600개 표본만으로 트리 구성
        max_samples = min(256, n) if n <= 10000 else min(25600, n)
        model = IsolationForest(
            contamination=contamination,
            random_state=42,
            n_estimators=50,
            max_samples=max_samples,
            n_jobs=-1,  # 멀티코어 병렬 처리
        )
        preds = model.fit_predict(series.values.reshape(-1, 1))
        return (preds == -1)
    except Exception:
        return np.zeros(len(series), dtype=bool)


def check_outliers_ensemble(df: pd.DataFrame) -> Dict[str, Any]:
    """
    이상치 탐지 - 3개 알고리즘 다수결
    플로우차트: "2개 이상 검출 시 이상치"

    각 수치형 컬럼에 대해:
      - IQR
      - Z-Score
      - Isolation Forest
    위 3가지 중 2개 이상에서 이상치로 판정한 셀만 최종 이상치로 카운트.
    """
    numeric_df = df.select_dtypes(include="number")
    per_column: Dict[str, int] = {}
    per_method_count = {"iqr": 0, "zscore": 0, "isoforest": 0, "ensemble": 0}
    total_outliers = 0

    for col in numeric_df.columns:
        series = numeric_df[col].dropna()
        if len(series) < 4:
            per_column[col] = 0
            continue

        mask_iqr = _detect_outliers_iqr(series)
        mask_z = _detect_outliers_zscore(series)
        mask_iso = _detect_outliers_isoforest(series)

        # 셀별로 몇 개 알고리즘이 이상치라고 판정했는지 합산
        vote_sum = mask_iqr.astype(int) + mask_z.astype(int) + mask_iso.astype(int)
        ensemble_mask = vote_sum >= 2  # 다수결: 2표 이상

        per_method_count["iqr"] += int(mask_iqr.sum())
        per_method_count["zscore"] += int(mask_z.sum())
        per_method_count["isoforest"] += int(mask_iso.sum())
        per_method_count["ensemble"] += int(ensemble_mask.sum())

        per_column[col] = int(ensemble_mask.sum())
        total_outliers += int(ensemble_mask.sum())

    total_numeric_cells = numeric_df.size if numeric_df.size > 0 else 1
    overall_ratio = total_outliers / total_numeric_cells

    return {
        "score": round((1 - overall_ratio) * 100, 2),
        "total_count": total_outliers,
        "overall_ratio": float(overall_ratio),
        "per_column": per_column,
        "per_method_count": per_method_count,
        "method": "ensemble (IQR + Z-Score + IsolationForest, majority vote ≥ 2)",
    }


# ====================================================================
# 5) 중복성 (Uniqueness) - 중복/키 검사
# ====================================================================
def check_uniqueness(df: pd.DataFrame) -> Dict[str, Any]:
    """
    중복성: 중복 행이 적을수록 좋음
    점수 = (1 - 중복행/전체행) × 100
    """
    if len(df) == 0:
        return {"score": 100.0, "count": 0, "ratio": 0.0}

    duplicate_count = int(df.duplicated().sum())
    ratio = duplicate_count / len(df)

    return {
        "score": round((1 - ratio) * 100, 2),
        "count": duplicate_count,
        "ratio": float(ratio),
    }


# ====================================================================
# 통합 진단 (5개 지표 한 번에)
# ====================================================================
def run_all_checks(df: pd.DataFrame) -> Dict[str, Any]:
    """5대 지표를 한 번에 진단하여 dict로 반환"""
    return {
        "completeness": check_completeness(df),
        "validity":     check_validity(df),
        "consistency":  check_consistency(df),
        "accuracy":     check_outliers_ensemble(df),
        "uniqueness":   check_uniqueness(df),
    }
