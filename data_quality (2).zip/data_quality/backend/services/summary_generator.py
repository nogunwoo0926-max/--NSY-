"""
LLM 스타일 진단 요약 생성 (규칙 기반)
5대 지표 (완전성·유효성·일관성·이상치·중복성) 기반으로 자연어 요약 생성
"""
from typing import Dict, Any

from backend.services.quality_score import get_grade_description


def generate_summary(
    total_score: float,
    grade: str,
    diagnosis: Dict[str, Any],
) -> str:
    """
    5대 지표 진단 결과를 자연어 요약으로 변환

    Args:
        total_score: 종합 품질 점수 (0~100)
        grade: S/A/B/C/F 등급
        diagnosis: {"completeness":{...}, "validity":{...}, ...}
    """
    sentences = []

    # ① 전반 평가
    grade_desc = get_grade_description(grade)
    if grade == "S":
        overall = (
            f"현재 데이터셋은 <b>AI-Ready 등급 S (점수 {total_score:.1f}점)</b>로 평가되며, "
            f"{grade_desc}한 수준입니다. 별도의 전처리 없이도 학습/분석에 즉시 활용할 수 있습니다."
        )
    elif grade == "A":
        overall = (
            f"현재 데이터셋은 <b>AI-Ready 등급 A (점수 {total_score:.1f}점)</b>로 평가되며, "
            f"{grade_desc}한 수준입니다. 일부 지표를 보완하면 S등급에 도달 가능합니다."
        )
    elif grade == "B":
        overall = (
            f"현재 데이터셋은 <b>AI-Ready 등급 B (점수 {total_score:.1f}점)</b>로 평가되며, "
            f"{grade_desc}이 필요한 수준입니다."
        )
    elif grade == "C":
        overall = (
            f"현재 데이터셋은 <b>AI-Ready 등급 C (점수 {total_score:.1f}점)</b>로 평가되며, "
            f"분석/학습 전 전반적인 {grade_desc}가 요구됩니다."
        )
    else:  # F
        overall = (
            f"현재 데이터셋은 <b>AI-Ready 등급 F (점수 {total_score:.1f}점)</b>로 평가되며, "
            f"{grade_desc}으로 판정됩니다. 광범위한 데이터 정제가 우선되어야 합니다."
        )
    sentences.append(overall)

    # ② 5대 지표 점수 요약
    dim_scores = {
        "완전성":   diagnosis["completeness"]["score"],
        "유효성":   diagnosis["validity"]["score"],
        "일관성":   diagnosis["consistency"]["score"],
        "이상치":   diagnosis["accuracy"]["score"],
        "중복성":   diagnosis["uniqueness"]["score"],
    }
    # 가장 낮은 지표 1~2개 식별 → 개선 우선순위
    sorted_dims = sorted(dim_scores.items(), key=lambda x: x[1])
    worst = sorted_dims[:2]
    best = sorted_dims[-1]

    sentences.append(
        f"지표별 점수는 완전성 <b>{dim_scores['완전성']:.1f}</b>, "
        f"유효성 <b>{dim_scores['유효성']:.1f}</b>, "
        f"일관성 <b>{dim_scores['일관성']:.1f}</b>, "
        f"이상치 <b>{dim_scores['이상치']:.1f}</b>, "
        f"중복성 <b>{dim_scores['중복성']:.1f}</b>점으로 측정되었습니다. "
        f"가장 우수한 지표는 <code>{best[0]}</code>({best[1]:.1f}점)이며, "
        f"보완이 필요한 지표는 <code>{worst[0][0]}</code>({worst[0][1]:.1f}점)입니다."
    )

    # ③ 완전성 코멘트
    cm = diagnosis["completeness"]
    if cm["overall_ratio"] > 0:
        top_missing = sorted(cm["per_column"].items(), key=lambda x: x[1], reverse=True)
        top_missing = [(c, r) for c, r in top_missing if r > 0][:3]
        msg = f"<b>[완전성]</b> 전체 결측률은 {cm['overall_ratio']*100:.2f}%로 총 {cm['total_missing']:,}개의 결측 셀이 있습니다. "
        if top_missing:
            top_str = ", ".join([f"<code>{c}</code>({r*100:.1f}%)" for c, r in top_missing])
            msg += f"주요 결측 컬럼: {top_str}."
        sentences.append(msg)

    # ④ 유효성 코멘트
    vd = diagnosis["validity"]
    if vd["invalid_count"] > 0:
        msg = (
            f"<b>[유효성]</b> 타입/형식 오류 셀이 {vd['invalid_count']:,}개 발견되었습니다 "
            f"({vd['invalid_ratio']*100:.2f}%). "
        )
        if vd["issues"]:
            cols = ", ".join([f"<code>{i['column']}</code>" for i in vd["issues"][:3]])
            msg += f"타입 변환 권장 컬럼: {cols}."
        sentences.append(msg)

    # ⑤ 일관성 코멘트
    cs = diagnosis["consistency"]
    if cs["inconsistent_count"] > 0:
        msg = (
            f"<b>[일관성]</b> 형식 불일치 셀이 {cs['inconsistent_count']:,}개 감지되었습니다 "
            f"(공백/대소문자/구분자 혼용). 표기 정규화 권장."
        )
        sentences.append(msg)

    # ⑥ 이상치 코멘트
    ac = diagnosis["accuracy"]
    if ac["total_count"] > 0:
        pm = ac["per_method_count"]
        top_out = sorted(ac["per_column"].items(), key=lambda x: x[1], reverse=True)
        top_out = [(c, n) for c, n in top_out if n > 0][:3]
        msg = (
            f"<b>[이상치]</b> 3개 알고리즘 다수결 기반으로 {ac['total_count']:,}개의 이상치가 탐지되었습니다 "
            f"(IQR: {pm['iqr']:,}, Z-Score: {pm['zscore']:,}, IsolationForest: {pm['isoforest']:,}). "
        )
        if top_out:
            top_str = ", ".join([f"<code>{c}</code>({n:,})" for c, n in top_out])
            msg += f"주요 발생 컬럼: {top_str}."
        sentences.append(msg)

    # ⑦ 중복성 코멘트
    un = diagnosis["uniqueness"]
    if un["count"] > 0:
        sentences.append(
            f"<b>[중복성]</b> 중복 행이 {un['count']:,}건({un['ratio']*100:.2f}%) 존재하므로 "
            f"중복 제거(deduplication)를 권장합니다."
        )

    return "<br><br>".join(sentences)
