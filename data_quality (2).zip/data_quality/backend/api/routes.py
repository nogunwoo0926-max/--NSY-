"""
FastAPI 라우터 (REST 엔드포인트)
- POST   /api/diagnose       : CSV 업로드 + 5지표 진단 + DB 저장
- GET    /api/history        : 진단 이력 목록
- GET    /api/history/{id}   : 진단 이력 단건
- DELETE /api/history/{id}   : 진단 이력 삭제
- GET    /api/health         : 헬스 체크
"""
from typing import List
from fastapi import APIRouter, UploadFile, File, Form, Depends, HTTPException
from sqlalchemy.orm import Session

from backend.db.database import get_db
from backend.db import crud
from backend.schemas.diagnosis import DiagnosisHistoryOut, DiagnosisResult
from backend.services.diagnosis_service import load_csv_from_bytes, run_full_diagnosis

router = APIRouter(prefix="/api", tags=["diagnosis"])


@router.post("/diagnose", response_model=DiagnosisResult)
async def diagnose_csv(
    file: UploadFile = File(..., description="진단할 CSV 파일"),
    weight_completeness: float = Form(0.30, ge=0.0, le=1.0, description="완전성 가중치"),
    weight_validity:     float = Form(0.25, ge=0.0, le=1.0, description="유효성 가중치"),
    weight_consistency:  float = Form(0.20, ge=0.0, le=1.0, description="일관성 가중치"),
    weight_accuracy:     float = Form(0.15, ge=0.0, le=1.0, description="이상치 가중치"),
    weight_uniqueness:   float = Form(0.10, ge=0.0, le=1.0, description="중복성 가중치"),
    db: Session = Depends(get_db),
):
    """
    CSV 파일을 받아 5대 지표 데이터 품질을 진단하고 결과를 DB에 저장합니다.

    - **file**: 업로드 CSV
    - **weight_***: 5대 지표 가중치 (자동 정규화, 기본 30/25/20/15/10)
    """
    if not file.filename.lower().endswith(".csv"):
        raise HTTPException(status_code=400, detail="CSV 파일만 업로드 가능합니다.")

    content = await file.read()
    if not content:
        raise HTTPException(status_code=400, detail="파일이 비어 있습니다.")

    try:
        df = load_csv_from_bytes(content)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    if df.empty:
        raise HTTPException(status_code=400, detail="CSV에 데이터가 없습니다.")

    weights = {
        "completeness": weight_completeness,
        "validity":     weight_validity,
        "consistency":  weight_consistency,
        "accuracy":     weight_accuracy,
        "uniqueness":   weight_uniqueness,
    }

    try:
        result = run_full_diagnosis(db, file.filename, df, weights)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"진단 중 오류 발생: {e}")

    return result


@router.get("/history", response_model=List[DiagnosisHistoryOut])
def get_history(skip: int = 0, limit: int = 50, db: Session = Depends(get_db)):
    """진단 이력 목록 조회 (최신순)"""
    return crud.list_diagnoses(db, skip=skip, limit=limit)


@router.get("/history/{diagnosis_id}", response_model=DiagnosisHistoryOut)
def get_history_detail(diagnosis_id: int, db: Session = Depends(get_db)):
    """진단 이력 단건 조회"""
    record = crud.get_diagnosis_by_id(db, diagnosis_id)
    if record is None:
        raise HTTPException(status_code=404, detail="해당 ID의 진단 이력이 없습니다.")
    return record


@router.delete("/history/{diagnosis_id}")
def delete_history(diagnosis_id: int, db: Session = Depends(get_db)):
    """진단 이력 삭제"""
    success = crud.delete_diagnosis(db, diagnosis_id)
    if not success:
        raise HTTPException(status_code=404, detail="해당 ID의 진단 이력이 없습니다.")
    return {"deleted": True, "id": diagnosis_id}


@router.get("/health")
def health_check():
    """헬스 체크"""
    return {"status": "ok"}
