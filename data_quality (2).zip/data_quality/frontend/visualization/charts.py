"""
Plotly 다크 테마 차트
- 5대 지표 레이더 차트 (신규)
- 5대 지표 점수 bar 차트 (신규)
- 컬럼별 결측 / 문제 유형 비율 / 컬럼 품질 점수 / 컬럼별 이상치 / 이력 트렌드
"""
import pandas as pd
import plotly.graph_objects as go
from typing import Dict, Any, List

DARK_BG = "#0E1117"
PANEL_BG = "#1F2937"
FONT_COLOR = "#E5E7EB"

# 지표명 한글 매핑
DIM_LABELS = {
    "completeness": "완전성",
    "validity":     "유효성",
    "consistency":  "일관성",
    "accuracy":     "이상치",
    "uniqueness":   "중복성",
}


def _apply_dark_layout(fig: go.Figure, title: str = "") -> go.Figure:
    fig.update_layout(
        title=dict(text=title, font=dict(color=FONT_COLOR, size=16)),
        paper_bgcolor=DARK_BG,
        plot_bgcolor=PANEL_BG,
        font=dict(color=FONT_COLOR, family="Segoe UI, sans-serif"),
        xaxis=dict(gridcolor="#374151", zerolinecolor="#374151"),
        yaxis=dict(gridcolor="#374151", zerolinecolor="#374151"),
        margin=dict(l=40, r=20, t=60, b=40),
    )
    return fig


# ====================================================================
# 1) 5대 지표 레이더 차트 (NEW)
# ====================================================================
def plot_dimension_radar(dimension_scores: Dict[str, float]) -> go.Figure:
    """5대 품질 지표를 레이더 차트로 시각화"""
    labels = [DIM_LABELS[k] for k in DIM_LABELS.keys()]
    values = [dimension_scores.get(k, 0) for k in DIM_LABELS.keys()]

    # 레이더 차트는 닫힌 도형이므로 첫 값을 끝에 한 번 더 추가
    labels_closed = labels + [labels[0]]
    values_closed = values + [values[0]]

    fig = go.Figure(go.Scatterpolar(
        r=values_closed,
        theta=labels_closed,
        fill="toself",
        line=dict(color="#00D4FF", width=3),
        fillcolor="rgba(0, 212, 255, 0.25)",
        marker=dict(size=10, color="#C77DFF"),
        hovertemplate="<b>%{theta}</b><br>점수: %{r:.1f}점<extra></extra>",
    ))

    fig.update_layout(
        title=dict(text="🎯 5대 품질 지표 레이더", font=dict(color=FONT_COLOR, size=16)),
        polar=dict(
            bgcolor=PANEL_BG,
            radialaxis=dict(
                visible=True, range=[0, 100],
                gridcolor="#374151",
                tickfont=dict(color=FONT_COLOR, size=10),
            ),
            angularaxis=dict(
                gridcolor="#374151",
                tickfont=dict(color=FONT_COLOR, size=12),
            ),
        ),
        paper_bgcolor=DARK_BG,
        font=dict(color=FONT_COLOR),
        showlegend=False,
        margin=dict(l=60, r=60, t=80, b=40),
    )
    return fig


# ====================================================================
# 2) 5대 지표 점수 bar 차트 (NEW)
# ====================================================================
def plot_dimension_bar(dimension_scores: Dict[str, float], weights: Dict[str, float]) -> go.Figure:
    """5대 지표 점수 + 가중치 표시 막대 차트"""
    labels = [DIM_LABELS[k] for k in DIM_LABELS.keys()]
    values = [dimension_scores.get(k, 0) for k in DIM_LABELS.keys()]
    weight_labels = [f"가중치 {weights.get(k, 0)*100:.0f}%" for k in DIM_LABELS.keys()]

    fig = go.Figure(go.Bar(
        x=labels,
        y=values,
        marker=dict(
            color=values,
            colorscale=[[0, "#EF4444"], [0.5, "#F59E0B"], [1, "#10B981"]],
            showscale=False,
        ),
        text=[f"{v:.1f}점<br><span style='font-size:0.8em;color:#9CA3AF;'>{wl}</span>"
              for v, wl in zip(values, weight_labels)],
        textposition="outside",
        hovertemplate="<b>%{x}</b><br>점수: %{y:.2f}점<extra></extra>",
    ))
    fig.update_xaxes(title_text="")
    fig.update_yaxes(title_text="점수", range=[0, 115])
    return _apply_dark_layout(fig, "📊 5대 지표 점수 (가중치 표시)")


# ====================================================================
# 3) 컬럼별 결측치 bar chart
# ====================================================================
def plot_missing_by_column(completeness_info: Dict[str, Any]) -> go.Figure:
    per_col = completeness_info.get("per_column", {})
    if not per_col:
        return _apply_dark_layout(go.Figure(), "컬럼별 결측률 (데이터 없음)")

    df_plot = (
        pd.DataFrame({"column": list(per_col.keys()), "missing_ratio": list(per_col.values())})
        .assign(missing_pct=lambda d: d["missing_ratio"] * 100)
        .sort_values("missing_pct", ascending=True)
    )

    fig = go.Figure(go.Bar(
        x=df_plot["missing_pct"],
        y=df_plot["column"],
        orientation="h",
        marker=dict(
            color=df_plot["missing_pct"],
            colorscale=[[0, "#10B981"], [0.5, "#F59E0B"], [1, "#EF4444"]],
            showscale=False,
        ),
        text=[f"{v:.1f}%" for v in df_plot["missing_pct"]],
        textposition="outside",
        hovertemplate="<b>%{y}</b><br>결측률: %{x:.2f}%<extra></extra>",
    ))
    fig.update_xaxes(title_text="결측률 (%)")
    return _apply_dark_layout(fig, "컬럼별 결측률")


# ====================================================================
# 4) 문제 유형 비율 pie chart
# ====================================================================
def plot_problem_ratio_pie(diagnosis: Dict[str, Any]) -> go.Figure:
    """결측 / 무효(유효성 오류) / 비일관 / 이상치 / 중복 비율 파이"""
    values = [
        diagnosis["completeness"]["total_missing"],
        diagnosis["validity"]["invalid_count"],
        diagnosis["consistency"]["inconsistent_count"],
        diagnosis["accuracy"]["total_count"],
        diagnosis["uniqueness"]["count"],
    ]
    labels = ["결측", "무효(타입오류)", "비일관", "이상치", "중복"]
    colors = ["#EF4444", "#F97316", "#FBBF24", "#7B2CBF", "#3B82F6"]

    if sum(values) == 0:
        fig = go.Figure(go.Pie(
            labels=["문제 없음"], values=[1], hole=0.5,
            marker=dict(colors=["#10B981"]),
        ))
        return _apply_dark_layout(fig, "문제 유형 비율 (이상 없음)")

    fig = go.Figure(go.Pie(
        labels=labels, values=values, hole=0.5,
        marker=dict(colors=colors),
        textinfo="label+percent",
        hovertemplate="<b>%{label}</b><br>개수: %{value:,}<br>비율: %{percent}<extra></extra>",
    ))
    return _apply_dark_layout(fig, "데이터 품질 문제 유형 비율")


# ====================================================================
# 5) 컬럼별 품질 점수 bar
# ====================================================================
def plot_column_quality_bar(col_scores: Dict[str, float]) -> go.Figure:
    if not col_scores:
        return _apply_dark_layout(go.Figure(), "컬럼별 품질 점수 (데이터 없음)")

    df_plot = (
        pd.DataFrame({"column": list(col_scores.keys()), "score": list(col_scores.values())})
        .sort_values("score", ascending=False)
    )

    fig = go.Figure(go.Bar(
        x=df_plot["column"],
        y=df_plot["score"],
        marker=dict(
            color=df_plot["score"],
            colorscale=[[0, "#EF4444"], [0.5, "#F59E0B"], [1, "#10B981"]],
            showscale=True,
            colorbar=dict(title="점수", tickfont=dict(color=FONT_COLOR)),
        ),
        text=[f"{v:.1f}" for v in df_plot["score"]],
        textposition="outside",
        hovertemplate="<b>%{x}</b><br>품질 점수: %{y:.2f}점<extra></extra>",
    ))
    fig.update_xaxes(title_text="컬럼", tickangle=-30)
    fig.update_yaxes(title_text="품질 점수", range=[0, 110])
    return _apply_dark_layout(fig, "컬럼별 품질 점수")


# ====================================================================
# 6) 컬럼별 이상치 (앙상블)
# ====================================================================
def plot_column_outliers(accuracy_info: Dict[str, Any]) -> go.Figure:
    per_col = {k: v for k, v in accuracy_info.get("per_column", {}).items() if v > 0}
    if not per_col:
        return _apply_dark_layout(go.Figure(), "컬럼별 이상치 (없음)")

    df_plot = (
        pd.DataFrame({"column": list(per_col.keys()), "count": list(per_col.values())})
        .sort_values("count", ascending=True)
    )

    fig = go.Figure(go.Bar(
        x=df_plot["count"],
        y=df_plot["column"],
        orientation="h",
        marker=dict(color="#F59E0B"),
        text=df_plot["count"],
        textposition="outside",
    ))
    fig.update_xaxes(title_text="이상치 개수 (앙상블 다수결)")
    return _apply_dark_layout(fig, "컬럼별 이상치 개수")


# ====================================================================
# 7) 이상치 알고리즘별 탐지 결과 비교 (NEW)
# ====================================================================
def plot_outlier_method_compare(accuracy_info: Dict[str, Any]) -> go.Figure:
    """IQR vs Z-Score vs Isolation Forest vs Ensemble 비교"""
    pm = accuracy_info.get("per_method_count", {})
    if not pm or sum(pm.values()) == 0:
        return _apply_dark_layout(go.Figure(), "이상치 탐지 알고리즘 비교 (데이터 없음)")

    methods = ["IQR", "Z-Score", "Isolation Forest", "Ensemble (≥2표)"]
    keys = ["iqr", "zscore", "isoforest", "ensemble"]
    values = [pm.get(k, 0) for k in keys]
    colors = ["#3B82F6", "#10B981", "#F59E0B", "#7B2CBF"]

    fig = go.Figure(go.Bar(
        x=methods,
        y=values,
        marker=dict(color=colors),
        text=[f"{v:,}" for v in values],
        textposition="outside",
        hovertemplate="<b>%{x}</b><br>탐지 개수: %{y:,}<extra></extra>",
    ))
    fig.update_xaxes(title_text="")
    fig.update_yaxes(title_text="탐지 개수")
    return _apply_dark_layout(fig, "🔬 이상치 탐지 알고리즘 비교")


# ====================================================================
# 8) 진단 이력 트렌드 (5지표 + 종합 선)
# ====================================================================
def plot_history_trend(history: List[Dict[str, Any]]) -> go.Figure:
    """진단 이력 점수 트렌드 — 종합 + 5지표 다중선"""
    if not history:
        return _apply_dark_layout(go.Figure(), "진단 이력 (데이터 없음)")

    df = pd.DataFrame(history).sort_values("checked_at")

    fig = go.Figure()

    # 5대 지표 (얇은 선)
    dim_colors = {
        "completeness_score": ("완전성", "#10B981"),
        "validity_score":     ("유효성", "#F59E0B"),
        "consistency_score":  ("일관성", "#3B82F6"),
        "accuracy_score":     ("이상치", "#7B2CBF"),
        "uniqueness_score":   ("중복성", "#EF4444"),
    }
    for col, (label, color) in dim_colors.items():
        if col in df.columns:
            fig.add_trace(go.Scatter(
                x=df["checked_at"], y=df[col],
                name=label,
                mode="lines+markers",
                line=dict(color=color, width=1.5, dash="dot"),
                marker=dict(size=5),
            ))

    # 종합 점수 (굵은 선)
    fig.add_trace(go.Scatter(
        x=df["checked_at"], y=df["quality_score"],
        name="종합 점수",
        mode="lines+markers",
        line=dict(color="#00D4FF", width=4),
        marker=dict(size=11, color="#C77DFF"),
        text=df["filename"],
        hovertemplate="<b>%{text}</b><br>%{x}<br>종합 점수: %{y:.1f}<extra></extra>",
    ))

    fig.update_xaxes(title_text="검사 일시")
    fig.update_yaxes(title_text="점수", range=[0, 105])
    fig.update_layout(
        legend=dict(
            orientation="h",
            yanchor="bottom", y=1.02,
            xanchor="right", x=1,
            font=dict(color=FONT_COLOR, size=11),
        ),
    )
    return _apply_dark_layout(fig, "📈 진단 이력 추이 (5지표 + 종합)")
